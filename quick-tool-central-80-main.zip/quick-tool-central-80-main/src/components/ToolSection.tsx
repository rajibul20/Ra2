
import { ReactNode, useState } from "react";
import { cn } from "@/lib/utils";
import { ChevronDown, ChevronUp } from "lucide-react";

interface ToolSectionProps {
  title: string;
  children: ReactNode;
  className?: string;
  description?: string;
  collapsible?: boolean;
  featured?: boolean;
  columns?: 2 | 3 | 4 | 6;
}

const ToolSection = ({ 
  title, 
  children, 
  className, 
  description, 
  collapsible = false,
  featured = false,
  columns = 6
}: ToolSectionProps) => {
  const [isCollapsed, setIsCollapsed] = useState(false);

  const toggleCollapse = () => {
    if (collapsible) {
      setIsCollapsed(!isCollapsed);
    }
  };

  const getColumnsClass = () => {
    switch (columns) {
      case 2: return "grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-2";
      case 3: return "grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3";
      case 4: return "grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4";
      case 6: 
      default: return "grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6";
    }
  };

  return (
    <section className={cn(
      "py-8 border-b border-gray-100 last:border-0",
      featured && "bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg shadow-sm",
      className
    )}>
      <div className="flex items-center justify-between mb-2">
        <h2 className="text-2xl font-bold">{title}</h2>
        {collapsible && (
          <button 
            onClick={toggleCollapse}
            className="p-1 rounded-full hover:bg-gray-100 transition-colors"
            aria-label={isCollapsed ? "Expand section" : "Collapse section"}
          >
            {isCollapsed ? <ChevronDown className="h-5 w-5" /> : <ChevronUp className="h-5 w-5" />}
          </button>
        )}
      </div>
      
      {description && (
        <p className="text-gray-600 mb-6 max-w-3xl">{description}</p>
      )}
      
      {!isCollapsed && (
        <div className={cn("grid gap-3", getColumnsClass())}>
          {children}
        </div>
      )}
    </section>
  );
};

export default ToolSection;
