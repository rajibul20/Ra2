
import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";
import { useState } from "react";

interface ToolCardProps {
  icon: React.ReactNode;
  title: string;
  link: string;
  bgColor?: string;
  description?: string;
  isNew?: boolean;
  isPopular?: boolean;
  isPremium?: boolean;
}

const ToolCard = ({ 
  icon, 
  title, 
  link, 
  bgColor = "bg-blue-100", 
  description,
  isNew = false,
  isPopular = false,
  isPremium = false
}: ToolCardProps) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <Link 
      to={link} 
      className="block"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      aria-label={`Open ${title} tool`}
    >
      <div className={cn(
        "flex flex-col items-center p-4 transition-all duration-300 rounded-lg h-full",
        isHovered ? "shadow-md transform -translate-y-1" : "hover:shadow-sm"
      )}>
        <div className={cn("p-3 rounded-lg mb-3 flex items-center justify-center w-16 h-16", bgColor)}>
          {icon}
        </div>
        <span className="text-center text-sm font-medium text-gray-800 mb-1">{title}</span>
        
        {description && (
          <span className="text-center text-xs text-gray-500 mt-1 hidden md:block">{description}</span>
        )}
        
        <div className="flex gap-2 mt-1">
          {isNew && (
            <span className="inline-flex items-center rounded-full bg-green-100 px-2 py-0.5 text-xs font-medium text-green-800">
              New
            </span>
          )}
          {isPopular && (
            <span className="inline-flex items-center rounded-full bg-orange-100 px-2 py-0.5 text-xs font-medium text-orange-800">
              Popular
            </span>
          )}
          {isPremium && (
            <span className="inline-flex items-center rounded-full bg-purple-100 px-2 py-0.5 text-xs font-medium text-purple-800">
              Premium
            </span>
          )}
        </div>
      </div>
    </Link>
  );
};

export default ToolCard;
