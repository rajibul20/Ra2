import { useState } from "react";
import { Link } from "react-router-dom";
import { 
  Search, 
  Menu, 
  ChevronDown, 
  FileText, 
  FileImage, 
  Info, 
  Mail, 
  Shield, 
  Book,
  File,
  Layers,
  ScrollText,
  Settings,
  ExternalLink,
  Heart,
  Users,
  Lock,
  FileLock2,
  Merge,
  FileOutput,
  Download,
  Share2,
  Facebook,
  Twitter,
  Instagram,
  Cpu,
  Database,
  Terminal,
  HardDrive,
  Network,
  Scan,
  Zap
} from "lucide-react";
import DarkModeToggle from "./DarkModeToggle";
import { 
  Sheet, 
  SheetContent, 
  SheetTrigger 
} from "@/components/ui/sheet";
import { 
  Collapsible, 
  CollapsibleContent, 
  CollapsibleTrigger 
} from "@/components/ui/collapsible";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const Navbar = () => {
  const [open, setOpen] = useState<{[key: string]: boolean}>({
    company: false,
    convertFromPdf: false,
    convertToPdf: false,
    pdfEditor: false,
    systemTools: false
  });

  const toggleCollapsible = (section: string) => {
    setOpen(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const menuCategories = [
    {
      id: "company",
      label: "Company Info",
      icon: <Info className="h-5 w-5 mr-2 text-tool-blue" />,
      children: [
        { 
          label: "About us", 
          to: "/about", 
          icon: <Users className="h-4 w-4 mr-2 text-tool-purple" /> 
        },
        { 
          label: "Contact us", 
          to: "/contact", 
          icon: <Mail className="h-4 w-4 mr-2 text-tool-blue" /> 
        },
        { 
          label: "Privacy Policy", 
          to: "/privacy", 
          icon: <Shield className="h-4 w-4 mr-2 text-tool-green" /> 
        },
        { 
          label: "Terms & Conditions", 
          to: "/terms", 
          icon: <Book className="h-4 w-4 mr-2 text-tool-orange" /> 
        }
      ]
    },
    {
      id: "convertFromPdf",
      label: "Convert from PDF",
      icon: <FileText className="h-5 w-5 mr-2 text-tool-red" />,
      children: [
        { 
          label: "PDF to Word", 
          to: "/tools/pdf-to-word", 
          icon: <ScrollText className="h-4 w-4 mr-2 text-tool-blue" /> 
        },
        { 
          label: "PDF to PowerPoint", 
          to: "/tools/pdf-to-powerpoint", 
          icon: <Layers className="h-4 w-4 mr-2 text-tool-orange" /> 
        },
        { 
          label: "PDF to JPG", 
          to: "/tools/pdf-to-jpg", 
          icon: <FileImage className="h-4 w-4 mr-2 text-tool-green" /> 
        },
        { 
          label: "PDF to PNG", 
          to: "/tools/pdf-to-png", 
          icon: <FileImage className="h-4 w-4 mr-2 text-tool-purple" /> 
        }
      ]
    },
    {
      id: "convertToPdf",
      label: "Convert to PDF",
      icon: <FileText className="h-5 w-5 mr-2 text-tool-green" />,
      children: [
        { 
          label: "Word to PDF", 
          to: "/tools/word-to-pdf", 
          icon: <ScrollText className="h-4 w-4 mr-2 text-tool-blue" /> 
        },
        { 
          label: "PowerPoint to PDF", 
          to: "/tools/powerpoint-to-pdf", 
          icon: <Layers className="h-4 w-4 mr-2 text-tool-orange" /> 
        },
        { 
          label: "JPG to PDF", 
          to: "/tools/jpg-to-pdf", 
          icon: <FileImage className="h-4 w-4 mr-2 text-tool-green" /> 
        },
        { 
          label: "PNG to PDF", 
          to: "/tools/png-to-pdf", 
          icon: <FileImage className="h-4 w-4 mr-2 text-tool-purple" /> 
        }
      ]
    },
    {
      id: "pdfEditor",
      label: "PDF Editor Tools",
      icon: <Settings className="h-5 w-5 mr-2 text-tool-purple" />,
      children: [
        { 
          label: "Merge PDF", 
          to: "/tools/merge-pdf", 
          icon: <Merge className="h-4 w-4 mr-2 text-tool-blue" /> 
        },
        { 
          label: "Remove Pages", 
          to: "/tools/remove-pages", 
          icon: <FileOutput className="h-4 w-4 mr-2 text-tool-red" /> 
        },
        { 
          label: "Compress PDF", 
          to: "/tools/compress-pdf", 
          icon: <Download className="h-4 w-4 mr-2 text-tool-green" /> 
        },
        { 
          label: "Unlock PDF", 
          to: "/tools/unlock-pdf", 
          icon: <FileLock2 className="h-4 w-4 mr-2 text-tool-orange" /> 
        }
      ]
    },
    {
      id: "systemTools",
      label: "Advanced System Tools",
      icon: <Cpu className="h-5 w-5 mr-2 text-tool-blue" />,
      children: [
        { 
          label: "System Monitor", 
          to: "/tools/system-monitor", 
          icon: <Terminal className="h-4 w-4 mr-2 text-tool-blue" /> 
        },
        { 
          label: "Disk Analyzer", 
          to: "/tools/disk-analyzer", 
          icon: <HardDrive className="h-4 w-4 mr-2 text-tool-green" /> 
        },
        { 
          label: "Network Diagnostics", 
          to: "/tools/network-diagnostics", 
          icon: <Network className="h-4 w-4 mr-2 text-tool-orange" /> 
        },
        { 
          label: "Database Viewer", 
          to: "/tools/database-viewer", 
          icon: <Database className="h-4 w-4 mr-2 text-tool-purple" /> 
        },
        { 
          label: "Port Scanner", 
          to: "/tools/port-scanner", 
          icon: <Scan className="h-4 w-4 mr-2 text-tool-red" /> 
        },
        { 
          label: "Process Manager", 
          to: "/tools/process-manager", 
          icon: <Zap className="h-4 w-4 mr-2 text-tool-yellow" /> 
        }
      ]
    }
  ];

  const renderDesktopMenu = () => (
    <nav className="hidden md:flex items-center space-x-8">
      <Link to="/" className="text-gray-700 hover:text-tool-purple transition-colors duration-200 font-medium">
        Home
      </Link>
      
      {/* Desktop Dropdown Menus */}
      <DropdownMenu>
        <DropdownMenuTrigger className="flex items-center text-gray-700 hover:text-tool-purple transition-colors duration-200 font-medium">
          Tools <ChevronDown className="ml-1 h-4 w-4" />
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-56 p-2">
          <Link to="/more-tools">
            <DropdownMenuItem className="cursor-pointer">All Tools</DropdownMenuItem>
          </Link>
          <Link to="/tools/pdf-to-word">
            <DropdownMenuItem className="cursor-pointer">PDF Converters</DropdownMenuItem>
          </Link>
          <Link to="/tools/word-to-pdf">
            <DropdownMenuItem className="cursor-pointer">File Converters</DropdownMenuItem>
          </Link>
        </DropdownMenuContent>
      </DropdownMenu>
      
      <Link to="/contact" className="text-gray-700 hover:text-tool-purple transition-colors duration-200 font-medium">
        Contact
      </Link>
      <Link to="/legal" className="text-gray-700 hover:text-tool-purple transition-colors duration-200 font-medium">
        Legal
      </Link>
      <button className="text-gray-700 hover:text-tool-purple transition-colors duration-200">
        <Search className="w-5 h-5" />
      </button>
      <DarkModeToggle />
    </nav>
  );

  const renderMobileMenu = () => (
    <Sheet>
      <SheetTrigger asChild className="md:hidden">
        <button className="text-gray-700 focus:outline-none" aria-label="Open menu">
          <Menu className="h-6 w-6" />
        </button>
      </SheetTrigger>
      <SheetContent side="left" className="w-[300px] p-0 bg-white dark:bg-gray-900 overflow-y-auto">
        <div className="flex flex-col h-full">
          <div className="p-5 border-b border-gray-100 dark:border-gray-800">
            <div className="flex justify-between items-center">
              <Link to="/" className="flex items-center space-x-2">
                <span className="text-tool-blue font-bold text-2xl">
                  <span className="text-tool-navy">Multi</span>
                  tool<span className="text-tool-purple">Set</span>
                </span>
              </Link>
              <DarkModeToggle />
            </div>
          </div>
          
          {/* Social sharing section */}
          <div className="px-4 py-5 border-b border-gray-100 dark:border-gray-800 bg-gray-50 dark:bg-gray-800/50">
            <div className="text-center mb-3">
              <p className="text-gray-600 dark:text-gray-300 text-sm">If you love our tools, please share!</p>
            </div>
            <div className="flex justify-center space-x-6">
              <a href="#" className="text-blue-600 hover:text-blue-700 transition-colors">
                <Facebook className="h-6 w-6" />
              </a>
              <a href="#" className="text-sky-500 hover:text-sky-600 transition-colors">
                <Twitter className="h-6 w-6" />
              </a>
              <a href="#" className="text-pink-600 hover:text-pink-700 transition-colors">
                <Instagram className="h-6 w-6" />
              </a>
            </div>
          </div>
          
          {/* Simple links */}
          <div className="p-2">
            <Link 
              to="/" 
              className="flex items-center py-2.5 px-4 mb-1 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
            >
              Home
            </Link>
            <Link 
              to="/more-tools" 
              className="flex items-center py-2.5 px-4 mb-1 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
            >
              More Tools
            </Link>
          </div>
          
          <div className="px-2 py-1 flex-1 overflow-y-auto">
            {menuCategories.map((category) => (
              <Collapsible
                key={category.id}
                open={open[category.id]}
                onOpenChange={() => toggleCollapsible(category.id)}
                className="mb-2 rounded-lg overflow-hidden shadow-sm border border-gray-100 dark:border-gray-800"
              >
                <CollapsibleTrigger className="flex justify-between items-center w-full p-3.5 bg-gradient-to-r from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-900 hover:bg-gray-100 dark:hover:bg-gray-700 text-left transition-all duration-200 font-medium rounded-lg">
                  <div className="flex items-center">
                    {category.icon}
                    <span>{category.label}</span>
                  </div>
                  <ChevronDown className={`w-5 h-5 text-gray-500 transition-transform duration-200 ${open[category.id] ? 'rotate-180' : ''}`} />
                </CollapsibleTrigger>
                <CollapsibleContent className="bg-white dark:bg-gray-900">
                  <div className="py-1">
                    {category.children.map((item, index) => (
                      <Link
                        key={index}
                        to={item.to}
                        className="flex items-center py-3 px-4 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors text-gray-700 dark:text-gray-300"
                      >
                        {item.icon}
                        <span>{item.label}</span>
                      </Link>
                    ))}
                  </div>
                </CollapsibleContent>
              </Collapsible>
            ))}
          </div>
          
          {/* Footer with copyright */}
          <div className="mt-auto p-4 border-t border-gray-100 dark:border-gray-800 text-center">
            <div className="text-gray-500 dark:text-gray-400 text-sm">
              Made with <Heart className="inline-block h-4 w-4 text-red-500" fill="currentColor" /> by MultiToolSet
            </div>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );

  return (
    <header className="sticky top-0 z-50 bg-white/95 dark:bg-gray-900/95 backdrop-blur-sm border-b border-gray-200 dark:border-gray-800 shadow-sm">
      <div className="container mx-auto flex justify-between items-center py-4 px-6">
        <div className="flex items-center">
          <Link to="/" className="flex items-center space-x-2">
            <span className="text-tool-blue font-bold text-3xl">
              <span className="text-tool-navy">Multi</span>
              tool<span className="text-tool-purple">Set</span>
            </span>
          </Link>
        </div>
        {renderDesktopMenu()}
        {renderMobileMenu()}
      </div>
    </header>
  );
};

export default Navbar;
