
import React from "react";
import ToolCard from "@/components/ToolCard";
import ToolSection from "@/components/ToolSection";
import { 
  JsonIcon,
  HtmlIcon,
  CssIcon
} from "@/components/icons/ToolIcons";

const DeveloperTools = () => {
  return (
    <ToolSection 
      title="Developer Tools"
      description="Essential tools for web developers and programmers to boost productivity."
    >
      <ToolCard 
        icon={<JsonIcon />} 
        title="JSON Formatter" 
        link="/tools/json-formatter"
        bgColor="bg-purple-100"
        isPopular={true}
        description="Format and validate JSON"
      />
      <ToolCard 
        icon={<HtmlIcon />} 
        title="HTML to Markdown" 
        link="/tools/html-to-markdown"
        bgColor="bg-orange-100"
        description="Convert HTML to Markdown"
      />
      <ToolCard 
        icon={<CssIcon />} 
        title="CSS Minifier" 
        link="/tools/css-minifier"
        bgColor="bg-green-100"
        description="Minify CSS code"
      />
      <ToolCard 
        icon={<JsonIcon />} 
        title="JavaScript Minifier" 
        link="/tools/javascript-minifier"
        bgColor="bg-blue-100"
        description="Minify JavaScript code"
      />
      <ToolCard 
        icon={<JsonIcon />} 
        title="SQL Formatter" 
        link="/tools/sql-formatter"
        bgColor="bg-teal-100"
        description="Format SQL queries"
      />
      <ToolCard 
        icon={<HtmlIcon />} 
        title="Base64 Encoder" 
        link="/tools/base64-encoder"
        bgColor="bg-pink-100"
        description="Encode/decode Base64"
      />
      <ToolCard 
        icon={<HtmlIcon />} 
        title="CSV to JSON" 
        link="/tools/csv-to-json"
        bgColor="bg-emerald-100"
        isNew={true}
        description="Convert CSV to JSON format"
      />
      <ToolCard 
        icon={<JsonIcon />} 
        title="JSON to CSV" 
        link="/tools/json-to-csv"
        bgColor="bg-red-100"
        isNew={true}
        description="Convert JSON to CSV format"
      />
      <ToolCard 
        icon={<JsonIcon />} 
        title="RegEx Tester" 
        link="/tools/regex-tester"
        bgColor="bg-yellow-100"
        isPopular={true}
        description="Test regular expressions"
      />
      <ToolCard 
        icon={<JsonIcon />} 
        title="JWT Decoder" 
        link="/tools/jwt-decoder"
        bgColor="bg-indigo-100"
        isNew={true}
        description="Decode JWT tokens"
      />
    </ToolSection>
  );
};

export default DeveloperTools;
