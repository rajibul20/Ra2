
import React from "react";
import ToolCard from "@/components/ToolCard";
import ToolSection from "@/components/ToolSection";
import { 
  WordCounterIcon,
  CharacterCounterIcon,
  CaseConverterIcon,
  PlagiarismIcon
} from "@/components/icons/ToolIcons";

const TextContentTools = () => {
  return (
    <ToolSection 
      title="Text & Content Tools"
      description="Analyze and manipulate text with these powerful text processing tools."
    >
      <ToolCard 
        icon={<WordCounterIcon />} 
        title="Word Counter" 
        link="/tools/word-counter"
        bgColor="bg-blue-100"
        isPopular={true}
        description="Count words in your text"
      />
      <ToolCard 
        icon={<CharacterCounterIcon />} 
        title="Character Counter" 
        link="/tools/character-counter"
        bgColor="bg-purple-100"
        description="Count characters with spaces"
      />
      <ToolCard 
        icon={<CaseConverterIcon />} 
        title="Case Converter" 
        link="/tools/case-converter"
        bgColor="bg-purple-100"
        description="Convert between text cases"
      />
      <ToolCard 
        icon={<PlagiarismIcon />} 
        title="Plagiarism Checker" 
        link="/tools/plagiarism-checker"
        bgColor="bg-orange-100"
        isPopular={true}
        description="Check content originality"
      />
      <ToolCard 
        icon={<CaseConverterIcon />} 
        title="Grammar Checker" 
        link="/tools/grammar-checker"
        bgColor="bg-green-100"
        description="Fix grammar errors in text"
      />
      <ToolCard 
        icon={<WordCounterIcon />} 
        title="Text to Speech" 
        link="/tools/text-to-speech"
        bgColor="bg-teal-100"
        description="Convert text to audio"
      />
      <ToolCard 
        icon={<WordCounterIcon />} 
        title="Text Diff Checker" 
        link="/tools/text-diff-checker"
        bgColor="bg-red-100"
        isNew={true}
        description="Compare text differences"
      />
      <ToolCard 
        icon={<WordCounterIcon />} 
        title="Lorem Ipsum Generator" 
        link="/tools/lorem-ipsum-generator"
        bgColor="bg-yellow-100"
        description="Generate placeholder text"
      />
      <ToolCard 
        icon={<WordCounterIcon />} 
        title="Text Repeater" 
        link="/tools/text-repeater"
        bgColor="bg-pink-100"
        description="Repeat text multiple times"
      />
      <ToolCard 
        icon={<WordCounterIcon />} 
        title="Word Frequency Counter" 
        link="/tools/word-frequency"
        bgColor="bg-indigo-100"
        isNew={true}
        description="Count word occurrences"
      />
    </ToolSection>
  );
};

export default TextContentTools;
