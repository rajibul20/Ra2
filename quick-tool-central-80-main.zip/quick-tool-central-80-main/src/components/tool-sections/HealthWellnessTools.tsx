
import React from "react";
import ToolCard from "@/components/ToolCard";
import ToolSection from "@/components/ToolSection";
import { 
  WeightIcon,
  AgeIcon,
  SpeedIcon,
  PercentIcon
} from "@/components/icons/ToolIcons";

const HealthWellnessTools = () => {
  return (
    <ToolSection 
      title="Health & Wellness Tools"
      description="Track, calculate, and optimize your health and wellness with these useful tools."
      featured={true}
    >
      <ToolCard 
        icon={<WeightIcon />} 
        title="BMI Calculator" 
        link="/tools/bmi-calculator"
        bgColor="bg-green-100"
        isPopular={true}
        description="Calculate Body Mass Index"
      />
      <ToolCard 
        icon={<WeightIcon />} 
        title="Calorie Counter" 
        link="/tools/calorie-counter"
        bgColor="bg-blue-100"
        description="Track daily calorie intake"
      />
      <ToolCard 
        icon={<AgeIcon />} 
        title="Pregnancy Calculator" 
        link="/tools/pregnancy-calculator"
        bgColor="bg-pink-100"
        description="Calculate due date and more"
      />
      <ToolCard 
        icon={<WeightIcon />} 
        title="Ideal Weight Calculator" 
        link="/tools/ideal-weight"
        bgColor="bg-purple-100"
        description="Find your ideal weight range"
      />
      <ToolCard 
        icon={<SpeedIcon />} 
        title="Pace Calculator" 
        link="/tools/pace-calculator"
        bgColor="bg-teal-100"
        isNew={true}
        description="Calculate running/walking pace"
      />
      <ToolCard 
        icon={<AgeIcon />} 
        title="Sleep Calculator" 
        link="/tools/sleep-calculator"
        bgColor="bg-indigo-100"
        isNew={true}
        description="Find ideal bedtime & wake time"
      />
      <ToolCard 
        icon={<PercentIcon />} 
        title="Body Fat Calculator" 
        link="/tools/body-fat-calculator"
        bgColor="bg-orange-100"
        description="Estimate body fat percentage"
      />
      <ToolCard 
        icon={<WeightIcon />} 
        title="Macro Calculator" 
        link="/tools/macro-calculator"
        bgColor="bg-emerald-100"
        description="Calculate macronutrient needs"
      />
      <ToolCard 
        icon={<PercentIcon />} 
        title="BMR Calculator" 
        link="/tools/bmr-calculator"
        bgColor="bg-red-100"
        isNew={true}
        description="Calculate basal metabolic rate"
      />
      <ToolCard 
        icon={<AgeIcon />} 
        title="Heart Rate Calculator" 
        link="/tools/heart-rate-calculator"
        bgColor="bg-rose-100"
        description="Find target heart rate zones"
      />
    </ToolSection>
  );
};

export default HealthWellnessTools;
