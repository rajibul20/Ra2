
import React from "react";
import ToolCard from "@/components/ToolCard";
import ToolSection from "@/components/ToolSection";
import { Cpu, Database, HardDrive, Network, Terminal, Zap, Scan } from "lucide-react";

const AdvancedSystemTools = () => {
  return (
    <ToolSection 
      title="Advanced System Tools"
      description="Professional system utilities and diagnostics for power users and IT professionals."
      featured={true}
      columns={4}
    >
      <ToolCard 
        icon={<Terminal className="h-6 w-6 text-blue-600" />} 
        title="System Monitor" 
        link="/tools/system-monitor"
        bgColor="bg-blue-100"
        isNew={true}
        description="Monitor system resources in real-time"
      />
      <ToolCard 
        icon={<HardDrive className="h-6 w-6 text-green-600" />} 
        title="Disk Analyzer" 
        link="/tools/disk-analyzer"
        bgColor="bg-green-100"
        isNew={true}
        description="Analyze disk usage and file distribution"
      />
      <ToolCard 
        icon={<Network className="h-6 w-6 text-orange-600" />} 
        title="Network Diagnostics" 
        link="/tools/network-diagnostics"
        bgColor="bg-orange-100"
        isNew={true}
        description="Diagnose network connectivity issues"
      />
      <ToolCard 
        icon={<Database className="h-6 w-6 text-purple-600" />} 
        title="Database Viewer" 
        link="/tools/database-viewer"
        bgColor="bg-purple-100"
        isPremium={true}
        description="View and manage databases"
      />
      <ToolCard 
        icon={<Cpu className="h-6 w-6 text-indigo-600" />} 
        title="Process Manager" 
        link="/tools/process-manager"
        bgColor="bg-indigo-100"
        isNew={true}
        description="Monitor and manage running processes"
      />
      <ToolCard 
        icon={<Scan className="h-6 w-6 text-red-600" />} 
        title="Port Scanner" 
        link="/tools/port-scanner"
        bgColor="bg-red-100"
        isPremium={true}
        description="Scan network ports for security analysis"
      />
      <ToolCard 
        icon={<Zap className="h-6 w-6 text-yellow-600" />} 
        title="Performance Analyzer" 
        link="/tools/performance-analyzer"
        bgColor="bg-yellow-100"
        isNew={true}
        description="Analyze and optimize system performance"
      />
      <ToolCard 
        icon={<Terminal className="h-6 w-6 text-teal-600" />} 
        title="Command Line Interface" 
        link="/tools/command-line"
        bgColor="bg-teal-100"
        isPremium={true}
        description="Access powerful terminal commands"
      />
    </ToolSection>
  );
};

export default AdvancedSystemTools;
