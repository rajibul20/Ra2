
import React from "react";
import ToolCard from "@/components/ToolCard";
import ToolSection from "@/components/ToolSection";
import { 
  ImageIcon,
  ResizeIcon,
  CompressIcon,
  QrCodeIcon,
  GifIcon
} from "@/components/icons/ToolIcons";

const ImageMediaTools = () => {
  return (
    <ToolSection 
      title="Image & Media Tools" 
      description="Edit, convert, and optimize your images and media files with these powerful tools."
    >
      <ToolCard 
        icon={<ImageIcon />} 
        title="Image to PNG Converter" 
        link="/tools/image-to-png"
        bgColor="bg-blue-100"
        isPopular={true}
        description="Convert JPG, WebP, GIF to PNG"
      />
      <ToolCard 
        icon={<ResizeIcon />} 
        title="Image Resizer" 
        link="/tools/image-resizer"
        bgColor="bg-blue-100"
        description="Resize images to exact dimensions"
      />
      <ToolCard 
        icon={<CompressIcon />} 
        title="Image Compressor" 
        link="/tools/image-compressor"
        bgColor="bg-teal-100"
        description="Reduce file size without losing quality"
      />
      <ToolCard 
        icon={<QrCodeIcon />} 
        title="QR Code Generator" 
        link="/tools/qr-code-generator"
        bgColor="bg-green-100"
        description="Create custom QR codes for URLs"
      />
      <ToolCard 
        icon={<GifIcon />} 
        title="GIF Maker" 
        link="/tools/gif-maker"
        bgColor="bg-orange-100"
        description="Create animated GIFs from images"
      />
      <ToolCard 
        icon={<ImageIcon />} 
        title="WebP Converter" 
        link="/tools/webp-converter"
        bgColor="bg-purple-100"
        isNew={true}
        description="Convert to/from WebP format"
      />
      <ToolCard 
        icon={<ImageIcon />} 
        title="Image Color Picker" 
        link="/tools/image-color-picker"
        bgColor="bg-pink-100"
        isNew={true}
        description="Extract colors from images"
      />
      <ToolCard 
        icon={<ImageIcon />} 
        title="Image Cropper" 
        link="/tools/image-cropper"
        bgColor="bg-yellow-100"
        description="Crop images to perfect size"
      />
      <ToolCard 
        icon={<ImageIcon />} 
        title="Image to Base64" 
        link="/tools/image-to-base64"
        bgColor="bg-red-100"
        description="Convert images to base64 strings"
      />
      <ToolCard 
        icon={<ImageIcon />} 
        title="SVG Editor" 
        link="/tools/svg-editor"
        bgColor="bg-emerald-100"
        isNew={true}
        description="Edit SVG files online"
      />
    </ToolSection>
  );
};

export default ImageMediaTools;
