
import React from "react";
import ToolCard from "@/components/ToolCard";
import ToolSection from "@/components/ToolSection";
import { 
  ImageIcon,
  JsonIcon
} from "@/components/icons/ToolIcons";

const SocialMediaTools = () => {
  return (
    <ToolSection 
      title="Social Media Tools"
      description="Enhance your social media presence with these powerful tools for content creation and management."
    >
      <ToolCard 
        icon={<ImageIcon />} 
        title="Social Media Post Creator" 
        link="/tools/social-post-creator"
        bgColor="bg-blue-100"
        isPopular={true}
        description="Create engaging social posts"
      />
      <ToolCard 
        icon={<ImageIcon />} 
        title="Hashtag Generator" 
        link="/tools/hashtag-generator"
        bgColor="bg-green-100"
        description="Generate trending hashtags"
      />
      <ToolCard 
        icon={<JsonIcon />} 
        title="Social Media Calendar" 
        link="/tools/social-calendar"
        bgColor="bg-purple-100"
        isNew={true}
        description="Plan your content schedule"
      />
      <ToolCard 
        icon={<JsonIcon />} 
        title="Bio Link Generator" 
        link="/tools/bio-link"
        bgColor="bg-pink-100"
        description="Create multi-link bios"
      />
    </ToolSection>
  );
};

export default SocialMediaTools;
