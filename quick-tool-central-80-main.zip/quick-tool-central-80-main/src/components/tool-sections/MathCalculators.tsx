
import React from "react";
import ToolCard from "@/components/ToolCard";
import ToolSection from "@/components/ToolSection";
import { 
  PercentIcon,
  AgeIcon,
  LoanIcon
} from "@/components/icons/ToolIcons";

const MathCalculators = () => {
  return (
    <ToolSection 
      title="Math & Calculators"
      description="From simple calculations to complex formulas, our math tools help you solve problems quickly."
    >
      <ToolCard 
        icon={<PercentIcon />} 
        title="Percentage Calculator" 
        link="/tools/percentage-calculator"
        bgColor="bg-red-100"
        isPopular={true}
        description="Calculate percentages easily"
      />
      <ToolCard 
        icon={<AgeIcon />} 
        title="Age Calculator" 
        link="/tools/age-calculator"
        bgColor="bg-blue-100"
        description="Calculate age between dates"
      />
      <ToolCard 
        icon={<LoanIcon />} 
        title="BMI Calculator" 
        link="/tools/bmi-calculator"
        bgColor="bg-green-100"
        description="Calculate Body Mass Index"
      />
      <ToolCard 
        icon={<LoanIcon />} 
        title="Loan EMI Calculator" 
        link="/tools/loan-calculator"
        bgColor="bg-green-100"
        isPopular={true}
        description="Calculate loan payments"
      />
      <ToolCard 
        icon={<PercentIcon />} 
        title="Currency Converter" 
        link="/tools/currency-converter"
        bgColor="bg-yellow-100"
        description="Convert between currencies"
      />
      <ToolCard 
        icon={<PercentIcon />} 
        title="Tip Calculator" 
        link="/tools/tip-calculator"
        bgColor="bg-pink-100"
        description="Calculate tips for bills"
      />
      <ToolCard 
        icon={<PercentIcon />} 
        title="Compound Interest" 
        link="/tools/compound-interest"
        bgColor="bg-purple-100"
        isNew={true}
        description="Calculate compound interest"
      />
      <ToolCard 
        icon={<PercentIcon />} 
        title="Discount Calculator" 
        link="/tools/discount-calculator"
        bgColor="bg-teal-100"
        description="Calculate price after discount"
      />
      <ToolCard 
        icon={<PercentIcon />} 
        title="GST Calculator" 
        link="/tools/gst-calculator"
        bgColor="bg-orange-100"
        description="Calculate tax inclusive prices"
      />
      <ToolCard 
        icon={<PercentIcon />} 
        title="Scientific Calculator" 
        link="/tools/scientific-calculator"
        bgColor="bg-indigo-100"
        isNew={true}
        description="Advanced math calculations"
      />
    </ToolSection>
  );
};

export default MathCalculators;
