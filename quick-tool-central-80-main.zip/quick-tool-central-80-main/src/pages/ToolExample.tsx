import { useParams } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import AdBanner from "@/components/AdBanner";
import { useState, useEffect, useRef } from "react";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { 
  ClipboardCopy, 
  Download, 
  ArrowRight, 
  Calculator, 
  Hash, 
  Key, 
  Lock,
  Image,
  Upload,
  FileText,
  Pencil,
  Code,
  Calendar,
  Percent,
  CreditCard,
  DollarSign,
  Clock,
  ImageIcon
} from "lucide-react";

// Define types for different tool configurations
interface BaseToolConfig {
  title: string;
  description: string;
  icon: React.ReactNode;
  category: string;
}

interface TextToolConfig extends BaseToolConfig {
  type: "text";
  inputLabel: string;
  outputLabel: string;
  inputPlaceholder: string;
  processFunction: (text: string) => string;
}

interface OptionToolConfig extends BaseToolConfig {
  type: "option";
  inputLabel: string;
  outputLabel: string;
  inputPlaceholder: string;
  options: Array<{ label: string; value: string }>;
  processFunction: (text: string, option: string) => string;
}

interface CalculatorToolConfig extends BaseToolConfig {
  type: "calculator";
  fields: Array<{
    name: string;
    label: string;
    type: string;
    placeholder: string;
    defaultValue?: any;
    defaultChecked?: boolean;
    min?: number;
    max?: number;
  }>;
  outputLabel?: string;
  processFunction: (fields: Record<string, any>) => string;
}

interface FileToolConfig extends BaseToolConfig {
  type: "file";
  acceptedFileTypes: string;
  maxFileSize: number; // in MB
  outputLabel: string;
  instructions: string;
  processFunction: (file: File) => Promise<string>;
  mockProcessFunction?: () => string; // For development purposes
}

type ToolConfig = TextToolConfig | OptionToolConfig | CalculatorToolConfig | FileToolConfig;

// Tool configurations for different tool types
const toolConfigs: Record<string, ToolConfig> = {
  // Image Processing Tools
  "image-to-png": {
    title: "Image to PNG Converter | Free Online PNG Converter",
    description: "Convert images to PNG format easily. Support for JPG, JPEG, WebP, GIF and more. Free online tool for high-quality PNG conversion.",
    icon: <Image className="w-6 h-6" />,
    category: "Image Tools",
    type: "file",
    acceptedFileTypes: "image/*",
    maxFileSize: 10,
    outputLabel: "Converted Image",
    instructions: "Upload an image in any format to convert it to high-quality PNG. Supports JPG, JPEG, WebP, GIF, and more formats.",
    processFunction: async (file: File) => {
      return "Image converted to PNG successfully!";
    }
  },

  "image-resizer": {
    title: "Free Image Resizer | Resize Images Online",
    description: "Resize your images online while maintaining quality. Support for all image formats, custom dimensions, and aspect ratio preservation.",
    icon: <ImageIcon className="w-6 h-6" />,
    category: "Image Tools",
    type: "calculator",
    fields: [
      { 
        name: "width", 
        label: "Width (px)", 
        type: "number", 
        placeholder: "Enter width", 
        defaultValue: 800,
        min: 1,
        max: 4096
      },
      { 
        name: "height", 
        label: "Height (px)", 
        type: "number", 
        placeholder: "Enter height",
        defaultValue: 600,
        min: 1,
        max: 4096
      },
      { 
        name: "maintainAspectRatio", 
        label: "Maintain Aspect Ratio", 
        type: "checkbox", 
        placeholder: "Keep aspect ratio",
        defaultChecked: true 
      }
    ],
    processFunction: (fields: Record<string, any>) => {
      return `Image will be resized to ${fields.width}x${fields.height} pixels`;
    }
  },

  "password-generator": {
    title: "Secure Password Generator | Create Strong Passwords",
    description: "Generate strong, secure passwords with custom requirements. Choose length, include symbols, numbers, and more for maximum security.",
    icon: <Lock className="w-6 h-6" />,
    category: "Security Tools",
    type: "calculator",
    fields: [
      { 
        name: "length", 
        label: "Password Length", 
        type: "number", 
        placeholder: "Enter length",
        defaultValue: 12,
        min: 4,
        max: 100 
      },
      { 
        name: "uppercase", 
        label: "Include Uppercase", 
        type: "checkbox",
        placeholder: "ABC",
        defaultChecked: true 
      },
      { 
        name: "lowercase", 
        label: "Include Lowercase", 
        type: "checkbox",
        placeholder: "abc",
        defaultChecked: true 
      },
      { 
        name: "numbers", 
        label: "Include Numbers", 
        type: "checkbox",
        placeholder: "123",
        defaultChecked: true 
      },
      { 
        name: "symbols", 
        label: "Include Symbols", 
        type: "checkbox",
        placeholder: "!@#",
        defaultChecked: true 
      }
    ],
    processFunction: (fields: Record<string, any>) => {
      const length = fields.length || 12;
      const uppercase = fields.uppercase !== false;
      const lowercase = fields.lowercase !== false;
      const numbers = fields.numbers !== false;
      const symbols = fields.symbols !== false;
      
      let chars = '';
      let password = '';
      
      if (uppercase) chars += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
      if (lowercase) chars += 'abcdefghijklmnopqrstuvwxyz';
      if (numbers) chars += '0123456789';
      if (symbols) chars += '!@#$%^&*()_+~`|}{[]\\:;?><,./-=';
      
      if (!chars) return "Please select at least one character type";
      
      for (let i = 0; i < length; i++) {
        password += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      
      return password;
    }
  },

  "word-counter": {
    title: "Word Counter | Count Words, Characters & More",
    description: "Free online word counter tool. Count words, characters, sentences, and paragraphs. Perfect for writers, students, and professionals.",
    icon: <FileText className="w-6 h-6" />,
    category: "Text Tools",
    type: "text",
    inputLabel: "Enter your text",
    outputLabel: "Text Statistics",
    inputPlaceholder: "Type or paste your text here...",
    processFunction: (text: string) => {
      const words = text.trim() ? text.trim().split(/\s+/).length : 0;
      const chars = text.length;
      const charNoSpaces = text.replace(/\s+/g, '').length;
      const sentences = text.split(/[.!?]+/).filter(Boolean).length;
      const paragraphs = text.split(/\n+/).filter(Boolean).length;
      
      return `Words: ${words}\nCharacters: ${chars}\nCharacters (without spaces): ${charNoSpaces}\nSentences: ${sentences}\nParagraphs: ${paragraphs}`;
    }
  },

  "case-converter": {
    title: "Case Converter | Convert Text Case Online",
    description: "Convert text case online - UPPERCASE, lowercase, Title Case, or Sentence case. Free tool for quick text case conversion.",
    icon: <Pencil className="w-6 h-6" />,
    category: "Text Tools",
    type: "option",
    inputLabel: "Enter your text",
    outputLabel: "Converted Text",
    inputPlaceholder: "Type or paste your text here...",
    options: [
      { label: "UPPERCASE", value: "upper" },
      { label: "lowercase", value: "lower" },
      { label: "Title Case", value: "title" },
      { label: "Sentence case", value: "sentence" }
    ],
    processFunction: (text: string, option: string) => {
      switch(option) {
        case "upper":
          return text.toUpperCase();
        case "lower":
          return text.toLowerCase();
        case "title":
          return text.replace(/\w\S*/g, (txt) => txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase());
        case "sentence":
          return text.charAt(0).toUpperCase() + text.slice(1).toLowerCase();
        default:
          return text;
      }
    }
  },

  "loan-calculator": {
    title: "Loan Calculator | EMI & Interest Calculator",
    description: "Calculate loan EMI, interest rates, and total payment. Perfect for mortgage, personal loans, and car loans calculation.",
    icon: <DollarSign className="w-6 h-6" />,
    category: "Finance Tools",
    type: "calculator",
    fields: [
      { 
        name: "amount", 
        label: "Loan Amount", 
        type: "number",
        placeholder: "Enter loan amount",
        defaultValue: 100000,
        min: 1
      },
      { 
        name: "interest", 
        label: "Interest Rate (%)", 
        type: "number",
        placeholder: "Enter interest rate",
        defaultValue: 10,
        min: 0,
        max: 100
      },
      { 
        name: "tenure", 
        label: "Loan Tenure (months)", 
        type: "number",
        placeholder: "Enter tenure in months",
        defaultValue: 12,
        min: 1,
        max: 360
      }
    ],
    processFunction: (fields: Record<string, any>) => {
      const P = fields.amount;
      const r = fields.interest / 1200; // monthly interest rate
      const n = fields.tenure;
      const emi = P * r * Math.pow(1 + r, n) / (Math.pow(1 + r, n) - 1);
      const totalPayment = emi * n;
      const totalInterest = totalPayment - P;
      
      return `EMI: $${emi.toFixed(2)}\nTotal Interest: $${totalInterest.toFixed(2)}\nTotal Payment: $${totalPayment.toFixed(2)}`;
    }
  }
};

// Add a default tool configuration for when a specific tool is not found
toolConfigs.default = {
  title: "Tool Not Found",
  description: "The tool you're looking for doesn't seem to exist or may have been moved.",
  icon: <FileText className="w-6 h-6" />,
  category: "Miscellaneous",
  type: "text",
  inputLabel: "Enter text",
  outputLabel: "Output",
  inputPlaceholder: "Enter text here...",
  processFunction: (text: string) => {
    return "Tool not available. Please try another tool from our collection.";
  }
};

const ToolExample = () => {
  const { toolId } = useParams<{ toolId: string }>();
  const [inputValue, setInputValue] = useState("");
  const [outputValue, setOutputValue] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedOption, setSelectedOption] = useState("");
  const [formValues, setFormValues] = useState<Record<string, any>>({});
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Get the tool configuration or use default if not found
  const toolConfig = toolId && toolConfigs[toolId as keyof typeof toolConfigs] 
    ? toolConfigs[toolId as keyof typeof toolConfigs] 
    : toolConfigs.default;
  
  // Set document title based on tool
  useEffect(() => {
    if (toolConfig) {
      document.title = `${toolConfig.title} | MultitoolSet`;
    } else {
      document.title = "Tool Not Found | MultitoolSet";
    }
  }, [toolConfig]);

  // Initialize form values for calculator-type tools
  useEffect(() => {
    if (toolConfig.type === "calculator" && toolConfig.fields) {
      const initialValues = toolConfig.fields.reduce((acc, field) => {
        if (field.type === 'checkbox') {
          acc[field.name] = field.defaultChecked !== undefined ? field.defaultChecked : false;
        } else {
          acc[field.name] = field.defaultValue || '';
        }
        return acc;
      }, {} as Record<string, any>);
      setFormValues(initialValues);
    }
  }, [toolId]);

  const handleProcess = () => {
    setIsProcessing(true);
    
    try {
      setTimeout(async () => {
        let result;
        
        switch (toolConfig.type) {
          case "calculator":
            result = toolConfig.processFunction(formValues);
            break;
          case "option":
            result = toolConfig.processFunction(inputValue, selectedOption || toolConfig.options[0].value);
            break;
          case "file":
            if (selectedFile) {
              try {
                result = await toolConfig.processFunction(selectedFile);
              } catch (error) {
                result = `Error processing file: ${error instanceof Error ? error.message : 'Unknown error'}`;
              }
            } else if (toolConfig.mockProcessFunction) {
              // For development/demo purposes
              result = toolConfig.mockProcessFunction();
            } else {
              result = "Please select a file to process";
            }
            break;
          default:
            result = toolConfig.processFunction(inputValue);
        }
        
        setOutputValue(result);
        setIsProcessing(false);
      }, 500); // Simulate processing time
    } catch (error) {
      setOutputValue(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
      setIsProcessing(false);
    }
  };
  
  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInputValue(e.target.value);
  };
  
  const handleFormValueChange = (name: string, value: any) => {
    setFormValues(prev => ({ ...prev, [name]: value }));
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    setSelectedFile(file);
    
    if (file) {
      // Check file size
      const fileConfig = toolConfig as FileToolConfig;
      const maxSize = fileConfig.maxFileSize * 1024 * 1024; // Convert MB to bytes
      if (file.size > maxSize) {
        toast.error(`File size exceeds the maximum allowed size of ${fileConfig.maxFileSize}MB`);
        setSelectedFile(null);
        e.target.value = '';
        return;
      }
      
      toast.success(`File "${file.name}" selected successfully!`);
    }
  };
  
  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };
  
  const handleCopyOutput = () => {
    navigator.clipboard.writeText(outputValue);
    toast.success("Copied to clipboard!");
  };
  
  // We'll mock this function since we don't have access to filesystem
  const handleDownload = () => {
    toast.success("Download started!");
    // In real implementation, create a blob and trigger download
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Navbar />
      <main className="flex-grow">
        <div className="container mx-auto px-6 py-12">
          <div className="flex flex-col items-center mb-6">
            <div className="bg-purple-100 p-3 rounded-full mb-4">
              {toolConfig.icon}
            </div>
            <h1 className="text-3xl font-bold text-center mb-2">
              {toolConfig.title}
            </h1>
            <p className="text-gray-600 text-center max-w-2xl mb-8">
              {toolConfig.description}
            </p>
          </div>
          
          <AdBanner className="mb-8" />
          
          <div className="bg-white rounded-lg shadow-md p-6">
            {/* File upload tools */}
            {toolConfig.type === "file" && (
              <div className="mb-6">
                <h3 className="font-medium text-gray-700 mb-4">Upload File</h3>
                <p className="text-gray-600 mb-4">{(toolConfig as FileToolConfig).instructions}</p>
                
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                  <input
                    type="file"
                    ref={fileInputRef}
                    className="hidden"
                    onChange={handleFileChange}
                    accept={(toolConfig as FileToolConfig).acceptedFileTypes}
                  />
                  
                  {!selectedFile ? (
                    <div>
                      <Upload className="mx-auto h-12 w-12 text-gray-400" />
                      <p className="mt-2 text-sm text-gray-600">
                        Drag and drop your file here, or{' '}
                        <button 
                          type="button" 
                          className="text-purple-600 hover:text-purple-500 font-medium"
                          onClick={triggerFileInput}
                        >
                          browse
                        </button>
                      </p>
                      <p className="mt-1 text-xs text-gray-500">
                        Maximum file size: {(toolConfig as FileToolConfig).maxFileSize}MB
                      </p>
                    </div>
                  ) : (
                    <div>
                      <FileText className="mx-auto h-12 w-12 text-purple-600" />
                      <p className="mt-2 text-sm text-gray-800 font-medium">
                        {selectedFile.name}
                      </p>
                      <p className="mt-1 text-xs text-gray-500">
                        {(selectedFile.size / 1024 / 1024).toFixed(2)}MB
                      </p>
                      <button
                        type="button"
                        className="mt-2 text-sm text-red-600 hover:text-red-500 font-medium"
                        onClick={() => {
                          setSelectedFile(null);
                          if (fileInputRef.current) fileInputRef.current.value = '';
                        }}
                      >
                        Remove
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}
            
            {/* Calculator-type tools */}
            {toolConfig.type === "calculator" && (
              <div className="mb-6">
                <h3 className="font-medium text-gray-700 mb-4">Enter Values</h3>
                <div className="space-y-4">
                  {toolConfig.fields.map((field) => (
                    <div key={field.name} className="flex flex-col">
                      <label className="block text-gray-700 font-medium mb-2">
                        {field.label}
                      </label>
                      {field.type === 'checkbox' ? (
                        <div className="flex items-center">
                          <input
                            type="checkbox"
                            checked={formValues[field.name] || false}
                            onChange={(e) => handleFormValueChange(field.name, e.target.checked)}
                            className="h-4 w-4 rounded border-gray-300 text-purple-600 focus:ring-purple-500"
                          />
                          <span className="ml-2 text-sm text-gray-600">Enable</span>
                        </div>
                      ) : (
                        <Input
                          type={field.type}
                          value={formValues[field.name] || ''}
                          onChange={(e) => handleFormValueChange(field.name, e.target.value)}
                          placeholder={field.placeholder}
                          min={field.min}
                          max={field.max}
                          className="w-full border border-gray-300 rounded-lg p-3"
                        />
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            {/* Text-based tools */}
            {(toolConfig.type === "text" || toolConfig.type === "option") && (
              <div className="mb-6">
                <label className="block text-gray-700 font-medium mb-2">
                  {toolConfig.inputLabel}
                </label>
                <Textarea 
                  className="w-full border border-gray-300 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-purple-500 bg-gray-50"
                  rows={5}
                  value={inputValue}
                  onChange={handleInputChange}
                  placeholder={toolConfig.inputPlaceholder}
                />
              </div>
            )}
            
            {/* Options for tools with multiple processing modes */}
            {toolConfig.type === "option" && (
              <div className="mb-6">
                <label className="block text-gray-700 font-medium mb-2">
                  Select Option
                </label>
                <select
                  value={selectedOption || (toolConfig.options[0]?.value || '')}
                  onChange={(e) => setSelectedOption(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-purple-500 bg-gray-50"
                >
                  {toolConfig.options.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>
            )}
            
            <div className="mb-6 flex justify-center">
              <Button
                className="bg-purple-600 hover:bg-purple-700 text-white font-medium py-2 px-6 rounded-lg transition-colors duration-300 flex items-center"
                onClick={handleProcess}
                disabled={isProcessing || (
                  (toolConfig.type === "text" || toolConfig.type === "option") && !inputValue ||
                  toolConfig.type === "file" && !selectedFile
                )}
              >
                {isProcessing ? "Processing..." : "Process"}
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
            
            {outputValue && (
              <div className="mt-6">
                <label className="block text-gray-700 font-medium mb-2">
                  {toolConfig.outputLabel}
                </label>
                <div className="w-full border border-gray-300 rounded-lg p-3 bg-gray-50 min-h-[100px] whitespace-pre-wrap">
                  {outputValue}
                </div>
                <div className="mt-4 flex justify-end">
                  <button 
                    className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium py-2 px-4 rounded-lg mr-2 flex items-center"
                    onClick={handleCopyOutput}
                  >
                    <ClipboardCopy className="mr-1 h-4 w-4" />
                    Copy
                  </button>
                  <button 
                    className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium py-2 px-4 rounded-lg flex items-center"
                    onClick={handleDownload}
                  >
                    <Download className="mr-1 h-4 w-4" />
                    Download
                  </button>
                </div>
              </div>
            )}
          </div>
          
          <div className="mt-12">
            <h2 className="text-2xl font-bold mb-4">How to Use This Tool</h2>
            <div className="bg-white rounded-lg shadow-sm p-6">
              <ol className="list-decimal pl-5 space-y-2 text-gray-700">
                {toolConfig.type === "file" ? (
                  <>
                    <li>Click the browse button or drag and drop your file into the upload area.</li>
                    <li>Select a file that meets the size and format requirements.</li>
                    <li>Click the "Process" button to begin processing.</li>
                    <li>View your results in the output area.</li>
                    <li>Download or copy the result as needed.</li>
                  </>
                ) : toolConfig.type === "calculator" ? (
                  <>
                    <li>Enter the required values in the form fields.</li>
                    <li>Make any adjustments to the options if needed.</li>
                    <li>Click the "Process" button.</li>
                    <li>View your results in the output area.</li>
                    <li>Copy or download the result as needed.</li>
                  </>
                ) : (
                  <>
                    <li>Enter or paste your text in the input field.</li>
                    {toolConfig.type === "option" && <li>Select the desired option for processing.</li>}
                    <li>Click the "Process" button.</li>
                    <li>View your results in the output area.</li>
                    <li>Copy or download the result as needed.</li>
                  </>
                )}
              </ol>
            </div>
          </div>
          
          <div className="mt-8">
            <h2 className="text-2xl font-bold mb-4">FAQs</h2>
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold text-lg">What is this tool for?</h3>
                  <p className="text-gray-700">{toolConfig.description}</p>
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Is my data secure?</h3>
                  <p className="text-gray-700">Yes, all processing happens in your browser. We don't store any of your data on our servers.</p>
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Can I use this tool for commercial purposes?</h3>
                  <p className="text-gray-700">Yes, this tool is free for both personal and commercial use.</p>
                </div>
              </div>
            </div>
          </div>
          
          <AdBanner className="my-8" />
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default ToolExample;
