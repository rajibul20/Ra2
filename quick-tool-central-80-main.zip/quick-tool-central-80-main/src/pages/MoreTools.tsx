
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import ToolCard from "@/components/ToolCard";
import ToolSection from "@/components/ToolSection";
import AdBanner from "@/components/AdBanner";
import {
  ImageIcon,
  ResizeIcon,
  CompressIcon,
  QrCodeIcon,
  GifIcon,
  MetaTagIcon,
  KeywordIcon,
  SitemapIcon,
  RobotsIcon,
  WordCounterIcon,
  CharacterCounterIcon,
  CaseConverterIcon,
  PlagiarismIcon,
  JsonIcon,
  HtmlIcon,
  CssIcon,
  LoanIcon,
  PercentIcon,
  AgeIcon,
  SpeedIcon,
  TemperatureIcon,
  LengthIcon,
  WeightIcon
} from "@/components/icons/ToolIcons";

const MoreTools = () => {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Navbar />
      <main className="flex-grow">
        <div className="container mx-auto px-6 py-12">
          <h1 className="text-4xl font-bold text-center mb-8">
            All Available Tools
          </h1>
          
          <AdBanner className="my-8" />
          
          <ToolSection title="Security & Encryption Tools">
            <ToolCard 
              icon={<JsonIcon />} 
              title="MD5 Hash Generator" 
              link="/tools/md5-generator"
              bgColor="bg-blue-100"
            />
            <ToolCard 
              icon={<JsonIcon />} 
              title="SHA256 Generator" 
              link="/tools/sha256-generator"
              bgColor="bg-green-100"
            />
            <ToolCard 
              icon={<JsonIcon />} 
              title="Password Generator" 
              link="/tools/password-generator"
              bgColor="bg-purple-100"
            />
            <ToolCard 
              icon={<JsonIcon />} 
              title="Random String Generator" 
              link="/tools/random-string"
              bgColor="bg-pink-100"
            />
            <ToolCard 
              icon={<JsonIcon />} 
              title="URL Shortener" 
              link="/tools/url-shortener"
              bgColor="bg-yellow-100"
            />
            <ToolCard 
              icon={<JsonIcon />} 
              title="SSL Certificate Checker" 
              link="/tools/ssl-checker"
              bgColor="bg-teal-100"
            />
          </ToolSection>
          
          <ToolSection title="Finance Calculators">
            <ToolCard 
              icon={<LoanIcon />} 
              title="EMI Calculator" 
              link="/tools/emi-calculator"
              bgColor="bg-green-100"
            />
            <ToolCard 
              icon={<LoanIcon />} 
              title="Loan Interest Calculator" 
              link="/tools/loan-interest"
              bgColor="bg-teal-100"
            />
            <ToolCard 
              icon={<LoanIcon />} 
              title="Mortgage Calculator" 
              link="/tools/mortgage-calculator"
              bgColor="bg-blue-100"
            />
            <ToolCard 
              icon={<LoanIcon />} 
              title="SIP Calculator" 
              link="/tools/sip-calculator"
              bgColor="bg-purple-100"
            />
            <ToolCard 
              icon={<LoanIcon />} 
              title="Income Tax Calculator" 
              link="/tools/income-tax-calculator"
              bgColor="bg-red-100"
            />
            <ToolCard 
              icon={<LoanIcon />} 
              title="GST Calculator" 
              link="/tools/gst-calculator"
              bgColor="bg-orange-100"
            />
          </ToolSection>
          
          <ToolSection title="Business Calculators">
            <ToolCard 
              icon={<PercentIcon />} 
              title="Profit Margin Calculator" 
              link="/tools/profit-margin"
              bgColor="bg-green-100"
            />
            <ToolCard 
              icon={<PercentIcon />} 
              title="Break-even Calculator" 
              link="/tools/break-even"
              bgColor="bg-blue-100"
            />
            <ToolCard 
              icon={<PercentIcon />} 
              title="ROI Calculator" 
              link="/tools/roi-calculator"
              bgColor="bg-purple-100"
            />
            <ToolCard 
              icon={<PercentIcon />} 
              title="Markup Calculator" 
              link="/tools/markup-calculator"
              bgColor="bg-red-100"
            />
            <ToolCard 
              icon={<PercentIcon />} 
              title="Payroll Calculator" 
              link="/tools/payroll-calculator"
              bgColor="bg-teal-100"
            />
            <ToolCard 
              icon={<PercentIcon />} 
              title="Depreciation Calculator" 
              link="/tools/depreciation-calculator"
              bgColor="bg-yellow-100"
            />
          </ToolSection>
          
          <ToolSection title="Social Media Tools">
            <ToolCard 
              icon={<ImageIcon />} 
              title="YouTube Thumbnail Downloader" 
              link="/tools/youtube-thumbnail"
              bgColor="bg-red-100"
            />
            <ToolCard 
              icon={<ImageIcon />} 
              title="Instagram Photo Downloader" 
              link="/tools/instagram-downloader"
              bgColor="bg-pink-100"
            />
            <ToolCard 
              icon={<ImageIcon />} 
              title="Twitter Video Downloader" 
              link="/tools/twitter-downloader"
              bgColor="bg-blue-100"
            />
            <ToolCard 
              icon={<ImageIcon />} 
              title="Facebook Video Downloader" 
              link="/tools/facebook-downloader"
              bgColor="bg-blue-200"
            />
            <ToolCard 
              icon={<KeywordIcon />} 
              title="Hashtag Generator" 
              link="/tools/hashtag-generator"
              bgColor="bg-purple-100"
            />
            <ToolCard 
              icon={<WordCounterIcon />} 
              title="Twitter Character Counter" 
              link="/tools/twitter-counter"
              bgColor="bg-teal-100"
            />
          </ToolSection>
          
          <AdBanner className="my-8" />
          
          {/* New Category: Health & Wellness Tools */}
          <ToolSection title="Health & Wellness Tools">
            <ToolCard 
              icon={<WeightIcon />} 
              title="BMI Calculator" 
              link="/tools/bmi-calculator"
              bgColor="bg-green-100"
            />
            <ToolCard 
              icon={<WeightIcon />} 
              title="Calorie Counter" 
              link="/tools/calorie-counter"
              bgColor="bg-blue-100"
            />
            <ToolCard 
              icon={<AgeIcon />} 
              title="Pregnancy Calculator" 
              link="/tools/pregnancy-calculator"
              bgColor="bg-pink-100"
            />
            <ToolCard 
              icon={<WeightIcon />} 
              title="Ideal Weight Calculator" 
              link="/tools/ideal-weight"
              bgColor="bg-purple-100"
            />
            <ToolCard 
              icon={<SpeedIcon />} 
              title="Pace Calculator" 
              link="/tools/pace-calculator"
              bgColor="bg-teal-100"
            />
            <ToolCard 
              icon={<AgeIcon />} 
              title="Sleep Calculator" 
              link="/tools/sleep-calculator"
              bgColor="bg-indigo-100"
            />
          </ToolSection>
          
          {/* New Category: Educational Tools */}
          <ToolSection title="Educational Tools">
            <ToolCard 
              icon={<WordCounterIcon />} 
              title="Flashcard Maker" 
              link="/tools/flashcard-maker"
              bgColor="bg-blue-100"
            />
            <ToolCard 
              icon={<JsonIcon />} 
              title="Citation Generator" 
              link="/tools/citation-generator"
              bgColor="bg-green-100"
            />
            <ToolCard 
              icon={<WordCounterIcon />} 
              title="Study Timer" 
              link="/tools/study-timer"
              bgColor="bg-purple-100"
            />
            <ToolCard 
              icon={<PercentIcon />} 
              title="Grade Calculator" 
              link="/tools/grade-calculator"
              bgColor="bg-teal-100"
            />
            <ToolCard 
              icon={<WordCounterIcon />} 
              title="Note Taker" 
              link="/tools/note-taker"
              bgColor="bg-pink-100"
            />
            <ToolCard 
              icon={<WordCounterIcon />} 
              title="Vocabulary Builder" 
              link="/tools/vocabulary-builder"
              bgColor="bg-yellow-100"
            />
          </ToolSection>
          
          <ToolSection title="Miscellaneous Tools">
            <ToolCard 
              icon={<QrCodeIcon />} 
              title="Barcode Generator" 
              link="/tools/barcode-generator"
              bgColor="bg-blue-100"
            />
            <ToolCard 
              icon={<ImageIcon />} 
              title="Meme Generator" 
              link="/tools/meme-generator"
              bgColor="bg-purple-100"
            />
            <ToolCard 
              icon={<HtmlIcon />} 
              title="Resume Builder" 
              link="/tools/resume-builder"
              bgColor="bg-green-100"
            />
            <ToolCard 
              icon={<HtmlIcon />} 
              title="Invoice Generator" 
              link="/tools/invoice-generator"
              bgColor="bg-teal-100"
            />
            <ToolCard 
              icon={<AgeIcon />} 
              title="Fake Address Generator" 
              link="/tools/fake-address"
              bgColor="bg-red-100"
            />
            <ToolCard 
              icon={<AgeIcon />} 
              title="Leap Year Checker" 
              link="/tools/leap-year"
              bgColor="bg-yellow-100"
            />
          </ToolSection>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default MoreTools;
