
import React, { useState } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import AdBanner from "@/components/AdBanner";
import SearchBar from "@/components/SearchBar";
import Features from "@/components/Features";
import WhyChooseUs from "@/components/WhyChooseUs";

// Import refactored tool section components
import ImageMediaTools from "@/components/tool-sections/ImageMediaTools";
import TextContentTools from "@/components/tool-sections/TextContentTools";
import DeveloperTools from "@/components/tool-sections/DeveloperTools";
import MathCalculators from "@/components/tool-sections/MathCalculators";
import HealthWellnessTools from "@/components/tool-sections/HealthWellnessTools";
import AdvancedSystemTools from "@/components/tool-sections/AdvancedSystemTools";
import AdditionalCategories from "@/components/tool-sections/AdditionalCategories";
import SocialMediaTools from "@/components/tool-sections/SocialMediaTools";

const Index = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [showAllCategories, setShowAllCategories] = useState(false);

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    console.log("Searching for:", query);
  };

  // Function to toggle showing all categories or just the main ones
  const toggleCategories = () => {
    setShowAllCategories(!showAllCategories);
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Navbar />
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Free Online Tools for Everyone
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-300 mb-8">
            Powerful, free, and easy-to-use online tools to help you be more productive.
          </p>
          <SearchBar onSearch={handleSearch} />
        </div>

        {/* Tool Sections */}
        <div className="space-y-8">
          <ImageMediaTools />
          <TextContentTools />
          <DeveloperTools />
          <SocialMediaTools />
          <AdBanner className="my-8" size="large" />
          <MathCalculators />
          <HealthWellnessTools />
          <AdvancedSystemTools />
        </div>
        
        {showAllCategories && <AdditionalCategories />}
        
        <div className="text-center mt-10 mb-16">
          <button
            onClick={toggleCategories}
            className="px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-full font-medium hover:from-blue-600 hover:to-purple-700 transition-all shadow-md hover:shadow-lg"
          >
            {showAllCategories ? "Show Less Tools" : "View More Tools"}
          </button>
        </div>
        
        {/* Features and Why Choose Us sections */}
        <Features />
        <WhyChooseUs />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
