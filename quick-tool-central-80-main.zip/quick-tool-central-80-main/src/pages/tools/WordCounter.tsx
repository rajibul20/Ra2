
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import AdBanner from "@/components/AdBanner";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ClipboardCopy, ArrowLeft } from "lucide-react";
import { toast } from "sonner";

const WordCounter = () => {
  const navigate = useNavigate();
  const [text, setText] = useState("");
  
  // Calculate text statistics
  const wordCount = text.trim() ? text.trim().split(/\s+/).length : 0;
  const charCount = text.length;
  const charNoSpacesCount = text.replace(/\s+/g, "").length;
  const sentenceCount = text.split(/[.!?]+/).filter(Boolean).length;
  const paragraphCount = text.split(/\n+/).filter(Boolean).length;
  const lineCount = text.split(/\r\n|\r|\n/).length;
  
  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setText(e.target.value);
  };
  
  const handleCopyToClipboard = () => {
    navigator.clipboard.writeText(text);
    toast.success("Text copied to clipboard!");
  };
  
  const handleClearText = () => {
    setText("");
    toast.info("Text cleared");
  };
  
  const handleGoBack = () => {
    navigate(-1);
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-900">
      <Navbar />
      
      <main className="flex-grow container mx-auto px-6 py-8">
        <div className="mb-6 flex items-center">
          <Button 
            variant="outline" 
            size="sm" 
            className="mr-4 flex items-center gap-1 text-gray-600 dark:text-gray-300"
            onClick={handleGoBack}
          >
            <ArrowLeft className="h-4 w-4" />
            Back
          </Button>
          <h1 className="text-3xl font-bold">Word Counter</h1>
        </div>
        
        <p className="text-gray-600 dark:text-gray-300 mb-8">
          Count words, characters, sentences, and paragraphs in your text. Perfect for writers, students, and professionals.
        </p>
        
        <AdBanner className="mb-8" />
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
              <h2 className="text-xl font-bold mb-4">Enter or paste your text</h2>
              <Textarea
                className="w-full h-80 resize-none mb-4 p-4"
                placeholder="Type or paste your text here..."
                value={text}
                onChange={handleTextChange}
              />
              
              <div className="flex space-x-4">
                <Button
                  variant="outline"
                  className="flex items-center"
                  onClick={handleCopyToClipboard}
                  disabled={!text}
                >
                  <ClipboardCopy className="h-4 w-4 mr-2" />
                  Copy Text
                </Button>
                
                <Button
                  variant="outline"
                  className="text-red-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20"
                  onClick={handleClearText}
                  disabled={!text}
                >
                  Clear Text
                </Button>
              </div>
            </div>
          </div>
          
          <div>
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 sticky top-24">
              <h2 className="text-xl font-bold mb-4">Text Statistics</h2>
              
              <div className="space-y-4">
                <div className="flex justify-between items-center pb-2 border-b dark:border-gray-700">
                  <span className="text-gray-600 dark:text-gray-300">Words</span>
                  <span className="text-xl font-bold">{wordCount}</span>
                </div>
                
                <div className="flex justify-between items-center pb-2 border-b dark:border-gray-700">
                  <span className="text-gray-600 dark:text-gray-300">Characters</span>
                  <span className="text-xl font-bold">{charCount}</span>
                </div>
                
                <div className="flex justify-between items-center pb-2 border-b dark:border-gray-700">
                  <span className="text-gray-600 dark:text-gray-300">Characters (no spaces)</span>
                  <span className="text-xl font-bold">{charNoSpacesCount}</span>
                </div>
                
                <div className="flex justify-between items-center pb-2 border-b dark:border-gray-700">
                  <span className="text-gray-600 dark:text-gray-300">Sentences</span>
                  <span className="text-xl font-bold">{sentenceCount}</span>
                </div>
                
                <div className="flex justify-between items-center pb-2 border-b dark:border-gray-700">
                  <span className="text-gray-600 dark:text-gray-300">Paragraphs</span>
                  <span className="text-xl font-bold">{paragraphCount}</span>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-gray-600 dark:text-gray-300">Lines</span>
                  <span className="text-xl font-bold">{lineCount}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 mt-8">
          <h2 className="text-2xl font-bold mb-4">About Word Counter</h2>
          <div className="text-gray-600 dark:text-gray-300 space-y-4">
            <p>
              Our word counter tool helps you count words, characters, sentences, paragraphs, and more in your text. 
              It's perfect for:
            </p>
            <ul className="list-disc pl-6 space-y-2">
              <li>Students checking essay word counts</li>
              <li>Writers working on articles with specific length requirements</li>
              <li>Social media posts with character limits</li>
              <li>SEO specialists analyzing content length</li>
              <li>Anyone who needs to analyze text statistics</li>
            </ul>
            <p>
              All processing happens in your browser, ensuring your text remains private and secure.
            </p>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default WordCounter;
