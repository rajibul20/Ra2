
import { useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import AdBanner from "@/components/AdBanner";
import { ImageIcon, Upload, ArrowRight, ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";

const ImageResizer = () => {
  const navigate = useNavigate();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [originalDimensions, setOriginalDimensions] = useState({ width: 0, height: 0 });
  const [width, setWidth] = useState(800);
  const [height, setHeight] = useState(600);
  const [maintainAspectRatio, setMaintainAspectRatio] = useState(true);
  const [quality, setQuality] = useState(90);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    if (file) {
      if (!file.type.startsWith('image/')) {
        toast.error("Please select an image file");
        return;
      }
      
      setSelectedFile(file);
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        setPreviewUrl(result);
        
        // Get original dimensions
        const img = new Image();
        img.onload = () => {
          setOriginalDimensions({ width: img.width, height: img.height });
          setWidth(img.width);
          setHeight(img.height);
        };
        img.src = result;
      };
      reader.readAsDataURL(file);
      toast.success("Image loaded successfully!");
    }
  };
  
  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };
  
  const updateDimension = (type: 'width' | 'height', value: number) => {
    if (type === 'width') {
      setWidth(value);
      if (maintainAspectRatio && originalDimensions.width > 0) {
        const ratio = originalDimensions.height / originalDimensions.width;
        setHeight(Math.round(value * ratio));
      }
    } else {
      setHeight(value);
      if (maintainAspectRatio && originalDimensions.height > 0) {
        const ratio = originalDimensions.width / originalDimensions.height;
        setWidth(Math.round(value * ratio));
      }
    }
  };
  
  const handleResize = () => {
    if (!selectedFile || !previewUrl) {
      toast.error("Please select an image first");
      return;
    }
    
    setIsProcessing(true);
    
    try {
      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      
      const img = new Image();
      img.onload = () => {
        if (ctx) {
          ctx.imageSmoothingEnabled = true;
          ctx.imageSmoothingQuality = 'high';
          ctx.drawImage(img, 0, 0, width, height);
          
          const resizedImageUrl = canvas.toDataURL('image/jpeg', quality / 100);
          setPreviewUrl(resizedImageUrl);
          
          toast.success("Image resized successfully!");
          setIsProcessing(false);
        }
      };
      img.src = previewUrl;
    } catch (error) {
      toast.error("Error resizing image");
      setIsProcessing(false);
    }
  };
  
  const handleDownload = () => {
    if (!previewUrl) return;
    
    const link = document.createElement('a');
    link.href = previewUrl;
    link.download = `resized_${selectedFile?.name || 'image.jpg'}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast.success("Image downloaded successfully!");
  };
  
  const handleGoBack = () => {
    navigate(-1);
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-900">
      <Navbar />
      
      <main className="flex-grow container mx-auto px-6 py-8">
        <div className="mb-6 flex items-center">
          <Button 
            variant="outline" 
            size="sm" 
            className="mr-4 flex items-center gap-1 text-gray-600 dark:text-gray-300"
            onClick={handleGoBack}
          >
            <ArrowLeft className="h-4 w-4" />
            Back
          </Button>
          <h1 className="text-3xl font-bold">Image Resizer</h1>
        </div>
        
        <p className="text-gray-600 dark:text-gray-300 mb-8 max-w-3xl">
          Resize your images quickly and easily while maintaining high quality. Perfect for social media, websites, or any project that requires specific image dimensions.
        </p>
        
        <AdBanner className="mb-8" />
        
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 mb-8">
          {!selectedFile ? (
            <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-8 text-center">
              <input
                type="file"
                ref={fileInputRef}
                className="hidden"
                onChange={handleFileChange}
                accept="image/*"
              />
              
              <ImageIcon className="mx-auto h-16 w-16 text-gray-400 dark:text-gray-500 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">Upload an image to resize</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                JPG, PNG, WebP, or GIF up to 10MB
              </p>
              
              <Button 
                className="bg-purple-600 hover:bg-purple-700 text-white"
                onClick={triggerFileInput}
              >
                <Upload className="h-4 w-4 mr-2" />
                Select Image
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div>
                <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-4">Resize Options</h3>
                
                <div className="space-y-6">
                  <div>
                    <Label htmlFor="width" className="mb-1 block">
                      Width (px): {width}
                    </Label>
                    <div className="flex items-center gap-2">
                      <Input
                        id="width"
                        type="number"
                        min="1"
                        max="4000"
                        value={width}
                        onChange={(e) => updateDimension('width', parseInt(e.target.value) || 0)}
                        className="w-full"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="height" className="mb-1 block">
                      Height (px): {height}
                    </Label>
                    <div className="flex items-center gap-2">
                      <Input
                        id="height"
                        type="number"
                        min="1"
                        max="4000"
                        value={height}
                        onChange={(e) => updateDimension('height', parseInt(e.target.value) || 0)}
                        className="w-full"
                      />
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="aspect-ratio"
                      checked={maintainAspectRatio}
                      onCheckedChange={setMaintainAspectRatio}
                    />
                    <Label htmlFor="aspect-ratio">Maintain aspect ratio</Label>
                  </div>
                  
                  <div>
                    <Label htmlFor="quality" className="mb-1 block">
                      Quality: {quality}%
                    </Label>
                    <Slider
                      id="quality"
                      min={10}
                      max={100}
                      step={1}
                      value={[quality]}
                      onValueChange={(value) => setQuality(value[0])}
                      className="w-full"
                    />
                  </div>
                  
                  <div className="flex gap-4">
                    <Button
                      className="bg-purple-600 hover:bg-purple-700 text-white"
                      onClick={handleResize}
                      disabled={isProcessing}
                    >
                      {isProcessing ? "Processing..." : "Resize Image"}
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                    
                    <Button
                      variant="outline"
                      onClick={handleDownload}
                      disabled={!previewUrl}
                    >
                      Download
                    </Button>
                    
                    <Button
                      variant="outline"
                      onClick={triggerFileInput}
                    >
                      Change Image
                    </Button>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-4">Preview</h3>
                <div className="border rounded-lg overflow-hidden bg-gray-100 dark:bg-gray-700 flex items-center justify-center h-[400px]">
                  {previewUrl && (
                    <img
                      src={previewUrl}
                      alt="Preview"
                      className="max-w-full max-h-full object-contain"
                    />
                  )}
                </div>
                <div className="mt-2 text-sm text-gray-500 dark:text-gray-400">
                  Original size: {originalDimensions.width} × {originalDimensions.height} px
                </div>
              </div>
            </div>
          )}
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 mb-8">
          <h2 className="text-2xl font-bold mb-4">How to Use</h2>
          <ol className="list-decimal pl-5 space-y-2">
            <li>Upload an image by clicking the select button or drag and drop.</li>
            <li>Set your desired width and height in pixels.</li>
            <li>Toggle "Maintain aspect ratio" if you want to preserve proportions.</li>
            <li>Adjust the quality slider for the output image.</li>
            <li>Click "Resize Image" to process your image.</li>
            <li>Preview the result and download when satisfied.</li>
          </ol>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default ImageResizer;
