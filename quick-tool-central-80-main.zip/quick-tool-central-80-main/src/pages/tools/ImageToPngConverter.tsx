
import { useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import AdBanner from "@/components/AdBanner";
import { ImageIcon, Upload, ArrowRight, Check, X, Info, Trash2, Download, ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

const ImageToPngConverter = () => {
  const navigate = useNavigate();
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [convertedFiles, setConvertedFiles] = useState<{ id: string; name: string; url: string; size: number }[]>([]);
  const [transparentBackground, setTransparentBackground] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const newFiles: File[] = [];
    let invalidFileFound = false;

    Array.from(files).forEach(file => {
      if (!file.type.startsWith('image/')) {
        invalidFileFound = true;
        return;
      }
      newFiles.push(file);
    });

    if (invalidFileFound) {
      toast.error("Some files are not images and were skipped");
    }

    if (newFiles.length > 0) {
      setSelectedFiles(prev => [...prev, ...newFiles]);
      toast.success(`${newFiles.length} image${newFiles.length > 1 ? 's' : ''} added`);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    
    const files = e.dataTransfer.files;
    if (!files || files.length === 0) return;

    const newFiles: File[] = [];
    let invalidFileFound = false;

    Array.from(files).forEach(file => {
      if (!file.type.startsWith('image/')) {
        invalidFileFound = true;
        return;
      }
      newFiles.push(file);
    });

    if (invalidFileFound) {
      toast.error("Some files are not images and were skipped");
    }

    if (newFiles.length > 0) {
      setSelectedFiles(prev => [...prev, ...newFiles]);
      toast.success(`${newFiles.length} image${newFiles.length > 1 ? 's' : ''} added`);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
  };

  const removeFile = (index: number) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const convertToPng = async () => {
    if (selectedFiles.length === 0) {
      toast.error("Please select at least one image to convert");
      return;
    }

    setIsProcessing(true);
    const results: { id: string; name: string; url: string; size: number }[] = [];

    try {
      for (const file of selectedFiles) {
        const result = await processImage(file);
        if (result) {
          results.push(result);
        }
      }

      setConvertedFiles(results);
      if (results.length > 0) {
        toast.success(`Successfully converted ${results.length} image${results.length > 1 ? 's' : ''} to PNG`);
      }
    } catch (error) {
      toast.error("Error converting images to PNG");
      console.error(error);
    } finally {
      setIsProcessing(false);
    }
  };

  const processImage = (file: File): Promise<{ id: string; name: string; url: string; size: number } | null> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      
      reader.onload = (event) => {
        const img = new Image();
        
        img.onload = () => {
          const canvas = document.createElement('canvas');
          canvas.width = img.width;
          canvas.height = img.height;
          
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            resolve(null);
            return;
          }
          
          // For transparent background
          if (transparentBackground) {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
          } else {
            ctx.fillStyle = 'white';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
          }
          
          ctx.drawImage(img, 0, 0);
          
          const pngUrl = canvas.toDataURL('image/png');
          const fileName = file.name.replace(/\.[^/.]+$/, "") + ".png";
          
          // Get the file size (approximate)
          const base64 = pngUrl.split(',')[1];
          const byteSize = Math.round((base64.length * 3) / 4);
          
          resolve({
            id: Math.random().toString(36).substring(2, 9),
            name: fileName,
            url: pngUrl,
            size: byteSize
          });
        };
        
        img.src = event.target?.result as string;
      };
      
      reader.onerror = () => {
        resolve(null);
      };
      
      reader.readAsDataURL(file);
    });
  };

  const downloadFile = (url: string, filename: string) => {
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const downloadAll = () => {
    if (convertedFiles.length === 0) return;
    
    convertedFiles.forEach(file => {
      downloadFile(file.url, file.name);
    });
    
    toast.success(`Downloaded ${convertedFiles.length} PNG file${convertedFiles.length > 1 ? 's' : ''}`);
  };
  
  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return bytes + ' B';
    else if (bytes < 1048576) return (bytes / 1024).toFixed(2) + ' KB';
    else return (bytes / 1048576).toFixed(2) + ' MB';
  };
  
  const handleGoBack = () => {
    navigate(-1);
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-900">
      <Navbar />
      
      <main className="flex-grow container mx-auto px-6 py-8">
        <div className="mb-6 flex items-center">
          <Button 
            variant="outline" 
            size="sm" 
            className="mr-4 flex items-center gap-1 text-gray-600 dark:text-gray-300"
            onClick={handleGoBack}
          >
            <ArrowLeft className="h-4 w-4" />
            Back
          </Button>
          <h1 className="text-3xl font-bold">Image to PNG Converter</h1>
        </div>
        
        <p className="text-gray-600 dark:text-gray-300 mb-8 max-w-3xl">
          Convert your images to PNG format with optional transparency. Batch convert multiple images at once.
        </p>
        
        <AdBanner className="mb-8" />
        
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h2 className="text-xl font-bold mb-4">Upload Images</h2>
              
              <div
                className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-8 text-center mb-4"
                onDrop={handleDrop}
                onDragOver={handleDragOver}
              >
                <input
                  type="file"
                  ref={fileInputRef}
                  className="hidden"
                  onChange={handleFileChange}
                  accept="image/*"
                  multiple
                />
                
                <ImageIcon className="mx-auto h-16 w-16 text-gray-400 dark:text-gray-500 mb-4" />
                <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
                  Drag & drop images here
                </h3>
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                  JPG, JPEG, WebP, GIF, BMP, etc.
                </p>
                
                <Button 
                  className="bg-purple-600 hover:bg-purple-700 text-white"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Upload className="h-4 w-4 mr-2" />
                  Select Files
                </Button>
              </div>
              
              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Switch
                    id="transparent-bg"
                    checked={transparentBackground}
                    onCheckedChange={setTransparentBackground}
                  />
                  <Label htmlFor="transparent-bg" className="cursor-pointer">
                    Enable transparent background
                  </Label>
                  <Info className="h-4 w-4 text-gray-500 dark:text-gray-400 cursor-help" 
                       title="Preserves transparency in images that support it" />
                </div>
                
                <Button
                  className="w-full bg-purple-600 hover:bg-purple-700 text-white"
                  onClick={convertToPng}
                  disabled={isProcessing || selectedFiles.length === 0}
                >
                  {isProcessing ? (
                    "Converting..."
                  ) : (
                    <>
                      Convert to PNG
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </>
                  )}
                </Button>
              </div>
            </div>
            
            <div>
              <h2 className="text-xl font-bold mb-4">Selected Files ({selectedFiles.length})</h2>
              
              {selectedFiles.length === 0 ? (
                <div className="text-center p-8 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  <p className="text-gray-500 dark:text-gray-400">No files selected</p>
                </div>
              ) : (
                <div className="overflow-y-auto max-h-60 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  {selectedFiles.map((file, index) => (
                    <div 
                      key={index} 
                      className="flex items-center justify-between p-3 border-b border-gray-200 dark:border-gray-600 last:border-0"
                    >
                      <div className="flex items-center">
                        <ImageIcon className="h-6 w-6 text-gray-500 dark:text-gray-400 mr-3" />
                        <div>
                          <p className="text-sm font-medium truncate max-w-[200px]">{file.name}</p>
                          <p className="text-xs text-gray-500 dark:text-gray-400">
                            {formatFileSize(file.size)}
                          </p>
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-red-500 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20"
                        onClick={() => removeFile(index)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
        
        {convertedFiles.length > 0 && (
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 mb-8">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">Converted PNG Files ({convertedFiles.length})</h2>
              <Button
                className="bg-green-600 hover:bg-green-700 text-white"
                onClick={downloadAll}
              >
                <Download className="h-4 w-4 mr-2" />
                Download All
              </Button>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {convertedFiles.map((file) => (
                <div 
                  key={file.id} 
                  className="border rounded-lg overflow-hidden flex flex-col bg-gray-50 dark:bg-gray-700"
                >
                  <div className="p-3 flex-grow bg-gray-100 dark:bg-gray-600 flex items-center justify-center h-40">
                    <img 
                      src={file.url} 
                      alt={file.name} 
                      className="max-w-full max-h-full object-contain"
                    />
                  </div>
                  
                  <div className="p-3">
                    <p className="text-sm font-medium truncate">{file.name}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mb-2">
                      {formatFileSize(file.size)}
                    </p>
                    
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full"
                      onClick={() => downloadFile(file.url, file.name)}
                    >
                      <Download className="h-4 w-4 mr-1" />
                      Download
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
          <h2 className="text-2xl font-bold mb-4">About PNG Conversion</h2>
          <div className="space-y-4">
            <p>
              PNG (Portable Network Graphics) is a raster graphics file format that supports lossless data compression. 
              PNG was created as an improved, non-patented replacement for GIF.
            </p>
            <h3 className="text-xl font-semibold">Advantages of PNG Format:</h3>
            <ul className="list-disc pl-5 space-y-1">
              <li>Lossless compression - maintains image quality</li>
              <li>Transparency support - creates images with transparent backgrounds</li>
              <li>Better color depth than GIF (up to 16 million colors)</li>
              <li>No copyright limitations</li>
              <li>Excellent for screenshots, logos, and images with text</li>
            </ul>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default ImageToPngConverter;
